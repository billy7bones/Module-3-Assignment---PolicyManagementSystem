import sys

# Add the directory to the Python module search path
sys.path.append(r"H:\My Drive\Nexford\MSc Business Analytics\Programming in R & Python - BAN6420\Module 3 - Objected-Oriented Programming in R and Python\Module 3 Assignment\PolicyManagementSystem")

# Import the classes from their respective files
from Policyholder import Policyholder
from Product import Product
from Payment import Payment

# Create products
product1 = Product(1, "Health Insurance", "Comprehensive health coverage", 5000)
product2 = Product(2, "Car Insurance", "Full car coverage", 3000)

# Create policyholders
'policyholder'
